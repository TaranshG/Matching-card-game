/**
 * File: js/Tile.js
 * Author: CS1XD3 Student
 * Description: Represents a single tile in the sliding puzzle.
 *              Tracks the tile's value and whether it is the blank tile.
 * Date: 2026
 */

"use strict";

/**
 * Tile class
 * Models the data for one tile on the puzzle grid.
 */
class Tile {

  /**
   * @param {number} value - The tile's number (0 = blank space).
   */
  constructor(value) {
    /** @type {number} The tile's number; 0 represents the blank space. */
    this.value = value;
  }

  /**
   * Returns true if this tile is the blank (empty) space.
   * @returns {boolean}
   */
  isBlank() {
    return this.value === 0;
  }

  /**
   * Returns a display string for the tile ("" for blank, number otherwise).
   * @returns {string}
   */
  toString() {
    return this.isBlank() ? "" : String(this.value);
  }
}
