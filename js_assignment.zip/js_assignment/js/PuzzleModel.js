/**
 * File: js/PuzzleModel.js
 * Author: CS1XD3 Student
 * Description: Models the entire state of the sliding-tiles puzzle.
 *              Handles board initialisation, guaranteed-solvable shuffling,
 *              move validation, tile sliding, win detection, progress
 *              calculation, and movable-tile reporting for UI affordances.
 * Date: 2026
 */

"use strict";

/**
 * PuzzleModel class
 * Stores and manipulates game state independently of the view (DOM).
 * The view should never write state back into this model; it only reads
 * the public getter methods.
 */
class PuzzleModel {

  /**
   * @param {number} size - Grid dimension (e.g. 3 for a 3×3 puzzle).
   */
  constructor(size) {
    /** @type {number} Grid dimension. */
    this.size = size;

    /** @type {Tile[]} Flat array of Tile objects (row-major order). */
    this.tiles = [];

    /** @type {number} Index of the blank tile within this.tiles. */
    this.blankIndex = 0;

    /** @type {number} Number of moves made in this round. */
    this.moves = 0;

    /** @type {boolean} True once the puzzle reaches the solved configuration. */
    this.solved = false;

    this._initBoard();
    this._shuffle();
  }

  // ─── Private Helpers ───────────────────────────────────────────────

  /**
   * Resets the tile array to the solved configuration.
   * Tiles are numbered 1 … (size²-1) followed by the blank (0).
   */
  _initBoard() {
    const total = this.size * this.size;
    this.tiles  = [];
    for (let i = 0; i < total - 1; i++) {
      this.tiles.push(new Tile(i + 1));
    }
    this.tiles.push(new Tile(0));   // blank always starts at the last cell
    this.blankIndex = total - 1;
    this.moves  = 0;
    this.solved = false;
  }

  /**
   * Shuffles the board by applying a large number of random legal moves,
   * which guarantees the resulting puzzle is always solvable.
   */
  _shuffle() {
    const iterations = this.size * this.size * 100;
    for (let i = 0; i < iterations; i++) {
      const neighbours = this._getNeighbours(this.blankIndex);
      const pick       = neighbours[Math.floor(Math.random() * neighbours.length)];
      this._swapWithBlank(pick);
    }
    this.moves  = 0;
    this.solved = false;
  }

  /**
   * Returns the grid indices of all cells adjacent (up/down/left/right)
   * to the given index.
   * @param {number} idx - Flat array index.
   * @returns {number[]} Array of adjacent indices.
   */
  _getNeighbours(idx) {
    const { size } = this;
    const row    = Math.floor(idx / size);
    const col    = idx % size;
    const result = [];
    if (row > 0)        result.push(idx - size);  // up
    if (row < size - 1) result.push(idx + size);  // down
    if (col > 0)        result.push(idx - 1);     // left
    if (col < size - 1) result.push(idx + 1);     // right
    return result;
  }

  /**
   * Swaps the tile at tileIdx with the blank tile and updates blankIndex.
   * @param {number} tileIdx - Index of the tile to swap with the blank.
   */
  _swapWithBlank(tileIdx) {
    const tmp              = this.tiles[tileIdx];
    this.tiles[tileIdx]    = this.tiles[this.blankIndex];
    this.tiles[this.blankIndex] = tmp;
    this.blankIndex        = tileIdx;
  }

  /**
   * Tests whether the board is currently in the solved configuration:
   * tiles 1…(n²-1) in ascending order, blank at the last position.
   * @returns {boolean}
   */
  _checkSolved() {
    const total = this.size * this.size;
    for (let i = 0; i < total - 1; i++) {
      if (this.tiles[i].value !== i + 1) return false;
    }
    return this.tiles[total - 1].isBlank();
  }

  // ─── Public API ────────────────────────────────────────────────────

  /**
   * Attempts to slide the tile at tileIdx toward the blank space.
   * Only tiles directly adjacent to the blank can move.
   * @param {number} tileIdx - Index of the tapped tile.
   * @returns {boolean} True if the move was valid and applied.
   */
  tryMove(tileIdx) {
    if (this.solved) return false;

    const neighbours = this._getNeighbours(this.blankIndex);
    if (!neighbours.includes(tileIdx)) return false;

    this._swapWithBlank(tileIdx);
    this.moves++;
    this.solved = this._checkSolved();
    return true;
  }

  /**
   * Resets the board to a freshly shuffled state.
   */
  reset() {
    this._initBoard();
    this._shuffle();
  }

  /**
   * Returns the indices of all tiles that are currently adjacent to the
   * blank and can therefore be slid.  Used by the view to apply affordance
   * highlighting.
   * @returns {number[]}
   */
  getMovableIndices() {
    return this._getNeighbours(this.blankIndex);
  }

  /**
   * Returns a completion percentage (0–100) representing how many tiles
   * are currently in their correct positions.
   * @returns {number}
   */
  getProgress() {
    const total   = this.size * this.size;
    let   correct = 0;
    for (let i = 0; i < total - 1; i++) {
      if (this.tiles[i].value === i + 1) correct++;
    }
    if (this.tiles[total - 1].isBlank()) correct++;
    return Math.round((correct / total) * 100);
  }

  /**
   * Returns the grid dimension.
   * @returns {number}
   */
  getSize() { return this.size; }

  /**
   * Returns the flat tile array.  View code should treat this as read-only.
   * @returns {Tile[]}
   */
  getTiles() { return this.tiles; }

  /**
   * Returns the current index of the blank tile.
   * @returns {number}
   */
  getBlankIndex() { return this.blankIndex; }

  /**
   * Returns the number of moves made this round.
   * @returns {number}
   */
  getMoves() { return this.moves; }

  /**
   * Returns true when the puzzle is solved.
   * @returns {boolean}
   */
  isSolved() { return this.solved; }
}
